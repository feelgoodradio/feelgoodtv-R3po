import sys
import xbmc
import xbmcplugin

STREAM_URL = "https://s11.ssl-stream.com/ssl/feelgoodradio?mp=/stream"

xbmc.Player().play(STREAM_URL)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
