import sys
import xbmcgui
import xbmcplugin

handle = int(sys.argv[1])

item = xbmcgui.ListItem(label="FeelgoodTV öffnen")
item.setInfo("video", {"title": "FeelgoodTV"})
xbmcplugin.addDirectoryItem(handle, "https://video.feelgoodtv.de", item, False)
xbmcplugin.endOfDirectory(handle)
