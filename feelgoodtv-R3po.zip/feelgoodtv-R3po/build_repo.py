from pathlib import Path
import hashlib
import shutil
import zipfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
REPO = ROOT / "repo"

REPO.mkdir(exist_ok=True)

addons = []
for addon_dir in sorted(SRC.iterdir()):
    if not addon_dir.is_dir():
        continue
    addon_xml = addon_dir / "addon.xml"
    if not addon_xml.exists():
        continue
    tree = ET.parse(addon_xml)
    addon = tree.getroot()
    addon_id = addon.attrib["id"]
    version = addon.attrib["version"]
    zip_name = f"{addon_id}-{version}.zip"
    zip_path = REPO / zip_name
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in addon_dir.rglob("*"):
            if path.is_file():
                zf.write(path, path.relative_to(SRC))
    addons.append(addon)

addons_root = ET.Element("addons")
for addon in addons:
    addons_root.append(addon)

addons_xml = REPO / "addons.xml"
ET.ElementTree(addons_root).write(addons_xml, encoding="utf-8", xml_declaration=True)
md5 = hashlib.md5(addons_xml.read_bytes()).hexdigest()
(REPO / "addons.xml.md5").write_text(md5, encoding="utf-8")
(REPO / "index.html").write_text("<h1>FEELGOODTV Kodi Repository</h1><p>Dieses Verzeichnis wird von Kodi verwendet.</p>", encoding="utf-8")
print("Fertig. Repo-Dateien liegen im Ordner: repo")
print("MD5:", md5)
