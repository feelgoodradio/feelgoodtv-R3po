# FEELGOODTV Kodi Repository — feelgoodtv-R3po

Dieses Projekt enthält ein eigenes Kodi-Repository für FEELGOODTV mit Beispiel-Add-ons für FeelgoodRadio und FeelgoodTV Videos.

## Wichtige Ordner

- `src/` = hier liegen die Quellordner der Kodi-Add-ons
- `repo/` = hier liegen die fertigen Dateien für GitHub Pages/Kodi
- `build_repo.py` = erstellt ZIP-Dateien, `addons.xml` und `addons.xml.md5`

## Veröffentlichung über GitHub Pages

1. Neues GitHub Repository erstellen: `feelgoodtv-R3po`
2. Diese Dateien hochladen.
3. In `src/repository.feelgoodtv/addon.xml` die Adresse ersetzen:
   `https://DEIN-GITHUB-NAME.github.io/feelgoodtv-R3po/repo/`
4. Danach lokal ausführen:
   `python build_repo.py`
5. Alles committen und zu GitHub hochladen.
6. GitHub → Repository → Settings → Pages → Deploy from a branch → Branch `main` → `/root` → Save.
7. Nach einigen Minuten ist das Repo erreichbar unter:
   `https://DEIN-GITHUB-NAME.github.io/feelgoodtv-R3po/repo/addons.xml`

## Kodi Installation

In Kodi:

1. Einstellungen → System → Add-ons → Unbekannte Quellen aktivieren.
2. Dateimanager → Quelle hinzufügen.
3. URL eingeben:
   `https://DEIN-GITHUB-NAME.github.io/feelgoodtv-R3po/repo/`
4. Name: `FEELGOODTV`
5. Add-ons → Aus ZIP-Datei installieren → FEELGOODTV → `repository.feelgoodtv-1.0.0.zip`
6. Danach: Aus Repository installieren → FEELGOODTV Repository.

## Hinweis

Nur legale Inhalte und eigene Streams einbinden.
